const { DataTypes, Model } = require('sequelize');

const { sequelizeCon } = require('../config/db-config');
const { Album } = require('../albums/model')
const { Usuario } = require('../usuarios/model');

class Musica extends Model {}
    
Musica.init({
    id_album: DataTypes.STRING,
    titulo: DataTypes.STRING,
    capa: DataTypes.STRING,
    duracao: DataTypes.NUMBER
}, { 
    sequelize: sequelizeCon, 
    schema: 'public',
    modelName: 'musicas'
});

Musica.belongsTo(Usuario);
Musica.belongsTo(Album, {
    foreignKey: 'id_album'
});

Usuario.hasMany(Album);
Album.hasMany(Musica, 
    {
        foreignKey: 'id_album'
    });

    
    sequelizeCon.sync();
    module.exports = { Musica };